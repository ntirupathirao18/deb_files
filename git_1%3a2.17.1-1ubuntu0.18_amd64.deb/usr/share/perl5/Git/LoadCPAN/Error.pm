package Git::LoadCPAN::Error;
use 5.008;
use strict;
use warnings;
use Git::LoadCPAN (
	module => 'Error',
	import => 1,
);

1;
